package com.curso.android;

import android.graphics.Canvas;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.View;

public class Graficos3Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GraficoView grafico = new GraficoView(this);
        setContentView(grafico);
    }
    private class GraficoView extends View{
    	public GraficoView(Context context){
    		super(context);
    	}
    	@Override
    	protected void onDraw(Canvas canvas){
    		
    		int bottom = getBottom();
    		int right = getRight();
    		int width = getMeasuredWidth();
    		int height = getMeasuredHeight();
    		
    		canvas.drawColor(Color.WHITE);
    		Paint paint = new Paint();
    		paint.setStyle(Paint.Style.FILL);
    		paint.setColor(Color.RED);
    		canvas.drawCircle(50, 50, 30, paint);
    		        canvas.drawRect(150, 50,200,100,paint);
    		paint.setColor(Color.BLUE);
    		canvas.drawCircle(50, 100, 30, paint);
    		canvas.drawRect(150, 150,200,200,paint);
    		paint.setColor(Color.GREEN);
    		canvas.drawCircle(50, 150, 30, paint);
    		canvas.drawRect(150, 250,200,300,paint);
    		/*_______*/
    		paint.setColor(Color.BLACK);
    		paint.setStyle(Paint.Style.STROKE);
    		canvas.drawCircle(50, 50, 30, paint);
    		paint.setStrokeWidth(4);
    		paint.setAntiAlias(true);
    		canvas.drawRect(150, 50,200,100,paint);
    		
    		canvas.drawRect(10,10,right-10,bottom-10, paint);
    		
    		Path path = new Path();
    		path.moveTo(0, 0);
    		for(int i=1; i<width; i++){
    			path.lineTo(i, (float)Math.sin(i/20f)*(-50f));
    		}
    		path.offset(0, 380);
    		//paint.setColor(Color.GREEN);
    		canvas.drawPath(path, paint);
    		
    		float[] intervalos = {10,10};
    		DashPathEffect dash = new DashPathEffect(intervalos, 1);
    		paint.setPathEffect(dash);
    		path.offset(0, 50);
    		canvas.drawPath(path, paint);

    		float[] intervalos1 = {10,2,10};
    		DashPathEffect dash1 = new DashPathEffect(intervalos1, 1);
    		paint.setPathEffect(dash1);
    		path.offset(0, 50);
    		canvas.drawPath(path, paint);
    		
    		float[] intervalos2 = {10,2,2,10};
    		DashPathEffect dash2 = new DashPathEffect(intervalos2, 1);
    		paint.setPathEffect(dash2);
    		path.offset(0, 50);
    		canvas.drawPath(path, paint);

    		
    		
    	}
}
}