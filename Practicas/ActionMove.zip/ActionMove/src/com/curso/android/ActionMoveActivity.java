package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class ActionMoveActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        SpecialView myView=new SpecialView(this);
        setContentView(myView);
    }
    class SpecialView extends View{
    	float x=50;
    	float y=50;
    	//
    	String texto="Evento";
    	//
    	public SpecialView(Context context){
    		super(context);
    	}
    	protected void onDraw(Canvas canvas){
    		canvas.drawColor(Color.LTGRAY);
    		Paint paint=new Paint();
    		paint.setAntiAlias(true);
    		paint.setColor(Color.RED);
    		canvas.drawCircle(x, y, 20, paint);
    		paint.setColor(Color.BLACK);
    		paint.setTextSize(35);
    		//
    		canvas.drawText(texto, 100, 130, paint);
    		//
    		canvas.drawText("x= "+x, 100, 50, paint);
    		canvas.drawText("y= "+y, 100, 90, paint);
    	}
    	public boolean onTouchEvent(MotionEvent evento){
    		x=evento.getX();
    		y=evento.getY(); 		
    		if(evento.getAction()==MotionEvent.ACTION_DOWN){
    			texto="Action Down";
    		}
    		if(evento.getAction()==MotionEvent.ACTION_UP){
    			texto="Action Up";
    		}
    		if(evento.getAction()==MotionEvent.ACTION_MOVE){
    			texto="Action Move";
    		}
    		invalidate();
    		return true;
    	}
     }
}