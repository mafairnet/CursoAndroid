package com.curso.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Textos2Activity extends Activity {
	
	EditText edittext;
	TextView tv;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        tv=(TextView) findViewById(R.id.text2);
        edittext=(EditText) findViewById(R.id.editText1);
        
        class MyKeyListener implements OnKeyListener{
        	
        	public boolean onKey(View v, int keyCode, KeyEvent event){
        		//Si se pulsa la tecla enter
        		if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)){
        			Toast.makeText(Textos2Activity.this, edittext.getText(),Toast.LENGTH_SHORT).show();
        			tv.setText("Bienvenido " + edittext.getText());
        			return true;
        		}
        		return false;
        	}
        }
        OnKeyListener listener = new MyKeyListener();
        edittext.setOnKeyListener(listener);
    }
}