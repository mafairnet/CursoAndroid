package com.curso.android;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Ficheros2Activity extends Activity {
	/**Leer un fichero en el directorio res*/
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView tv=(TextView)findViewById(R.id.texto);
        tv.append("\nLeer datos de res/raw/datos1.txt: ");
        InputStream input=getResources().openRawResource(R.raw.datos1);
        InputStreamReader stream=new InputStreamReader(input);
        BufferedReader buffer=new BufferedReader(stream,8192);
        try{
        	String linea;
        	while(true){
        		linea=buffer.readLine();
        		if(linea==null) break;
        		tv.append("\n"+linea);
        	}
        	input.close();
        	stream.close();
        	buffer.close();
        }catch(Exception e){
        	tv.append("\n "+e);
        }
        tv.append("\nFin del Archivo");
    }
}