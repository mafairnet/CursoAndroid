package com.curso.android;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class Actividad2 extends Activity {
	
	public static final String datoExtra = "dato1";
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actividad2);
        
        TextView texto = (TextView)findViewById(R.id.textView1);      
        String nombre = getIntent().getStringExtra("dato1");
        texto.append(nombre);
    }	
}



