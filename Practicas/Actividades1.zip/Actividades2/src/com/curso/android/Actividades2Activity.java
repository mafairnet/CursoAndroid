package com.curso.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class Actividades2Activity extends Activity implements OnClickListener{
	String nombre;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        View boton=findViewById(R.id.button1);
        boton.setOnClickListener(this);               
        nombre="Gerardo";
    }
    
    public void onClick(View v){
    	double[] nombre = new double[10];
    	for (int i=0; i<10;i++) nombre[i]=2*i;
    	Intent intencion = new Intent(this,Actividad2.class);
    	intencion.putExtra(Actividad2.datoExtra, nombre);
    	startActivity(intencion);
    	Toast.makeText(this, "Abriendo la segunda Actrividad", 1).show();
    }
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     */
}