package com.curso.android;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class BarraActivity extends Activity implements OnClickListener{
	
	ProgressDialog progreso; 
	Controlador handler=new Controlador();
	int maximo=100;
	int delay=100;
	TextView texto;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button boton= (Button) findViewById(R.id.button1);
        boton.setOnClickListener(this);
        texto=(TextView) findViewById(R.id.texto);    
    }

	@Override
	public void onClick(View v) {
		showDialog(1);
	}

    // Crea una barra de progeso 
    @Override
    public Dialog onCreateDialog(int id) {
    	
        progreso = new ProgressDialog(this);
        progreso.setProgressStyle(1); 
        progreso.setMessage("");
        return progreso;       
    }


    // Prepara la barra de progeso 
    @Override
    public void onPrepareDialog(int id,Dialog dialog) {
    	progreso=(ProgressDialog)dialog;
        progreso.setProgressStyle(1); 
        progreso.setMax(maximo);
        progreso.setProgress(0);
        progreso.setMessage("Ejecutando hilo en background...");
        Hilo thread=new Hilo();
        thread.start();       
    }

    class Controlador extends Handler{
    	@Override 
    	public void handleMessage(Message msg){
    		int total=msg.getData().getInt("total");
    		progreso.setProgress(total);
       		texto.setText("Total "+total+" Maximo: "+maximo);
    		if(total==maximo){
    			dismissDialog(1);
   			}		
    	}
    }  
    class Hilo extends Thread{
    	@Override
    	public void run(){
    		for (int i=0;i<=maximo;i++){
    		try{ 
    			Thread.sleep(delay);
    			} catch (InterruptedException e){;}
    		Message msg=handler.obtainMessage();
    		Bundle b =new Bundle();
    		b.putInt("total",i);
    		msg.setData(b);
    		handler.sendMessage(msg);
    		}    			
   		}
   	}
    	

}