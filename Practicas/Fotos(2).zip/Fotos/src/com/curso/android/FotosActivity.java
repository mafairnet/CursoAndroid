package com.curso.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FotosActivity extends Activity implements OnClickListener{

	ImageView foto;
	TextView tv;    // para escribir el texto de la foto
	int[] fotoId = {R.drawable.bisabuelo,
	        R.drawable.farmacia,
	        R.drawable.fernando_amaro,
	        R.drawable.tres_damas};
	String[] texto={"Bisabuelo","Abuelo","Tio","Abuela"};
	int i=0;      // numero de foto
	int total;   // numero total de fotos
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button anterior=(Button) findViewById(R.id.button1);
        Button siguiente=(Button) findViewById(R.id.button2);
        anterior.setOnClickListener(this);
        siguiente.setOnClickListener(this);

        tv=(TextView) findViewById(R.id.textView1);
        foto=(ImageView) findViewById(R.id.imageView1);
        total = fotoId.length;
    }

	public void onClick(View v) {
		
		int id=v.getId();
		// boton2 adelanta el numero de foto
		if(id==R.id.button2){
			i++;
			if (i == total) i=0;
			}
		// boton1 atrasa el numero de foto
		if(id==R.id.button1){
			i--;
			if (i == -1) i=total-1;
			}
		foto.setImageResource(fotoId[i]);
		tv.setText("Mi "+texto[i]);		
	}
}