package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

public class PelotaActivity extends Activity {
	
	boolean continuar=true;
	float velocidad=0.5f;
	float aceleracion=0.01f;
	float energia;
	int dt=1;
	int tiempo=0;
	Thread hilo=null;
	DinamicaView dinamica;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        dinamica=new DinamicaView(this);                
        setContentView(dinamica);
        hilo = new Thread(dinamica);
        hilo.start();        
    }
    
    // detenemos el hilo si pausa
    @Override
    public void onPause(){
    	super.onPause();
    	continuar=false;
    }

    // reiniciamos el hilo si resume
    @Override
    public void onResume(){
    	super.onResume();
    	continuar=true;
    	if(hilo==null){
    		hilo=new Thread(dinamica);
    		hilo.start();
    	}
    }
    
    class DinamicaView extends View implements Runnable{

    	int x,y,ymax;  // coordenadas
    	Paint paintFondo,paintParticula,paint;

    	public DinamicaView(Context context) {
			super(context);
			// Colores para el dibujo y tmaño del texto
			paintFondo=new Paint();
			paintParticula=new Paint();
			paint=new Paint();
			paintFondo.setColor(Color.WHITE);
			paintParticula.setColor(Color.RED);
			paint.setColor(Color.BLACK);
			paint.setTextSize(30);
    	}

		// obtiene geometria del canvas
		@Override
		protected void onSizeChanged(int w, int h, int oldw,int oldh){
			x=w/2;
			y=0;
			ymax=h;					
			energia=0.5f * velocidad * velocidad - aceleracion * y;
		}
    	
		@Override
		public void run() {

			while(continuar){				
				cambiaPosicion();
				postInvalidate();
				try { Thread.sleep( dt ); } 
				catch ( InterruptedException e ){ ; }	
			}    	
		}

		public void cambiaPosicion() {
			
				tiempo=tiempo+dt;
				// movimiento  y=y+v*dt
//				y=y+(int)(velocidad*dt);
				// fuerza v=v+a*dt
				velocidad=velocidad+aceleracion*dt;
				float cinetica=velocidad*velocidad/2;
				y=(int)((cinetica-energia)/aceleracion);
				// si llega abajo invertimos velocidad
				if(y>ymax) velocidad=-Math.abs(velocidad);
				// si llega arriba invertimos velocidad
				if(y<0) velocidad=Math.abs(velocidad);				
		}    	
		public void cambiaPosicion2() {
			
			tiempo=tiempo+dt;
			// movimiento  y=y+v*dt
			y=y+(int)(velocidad*dt);
			// fuerza v=v+a*dt
			velocidad=velocidad+aceleracion*dt;
			// si llega abajo invertimos velocidad
			if(y>ymax) velocidad=-velocidad;
			// si llega arriba invertimos velocidad
			if(y<0) velocidad=-velocidad;				
	}    	

		@Override
		public void onDraw(Canvas canvas ){			
			canvas.drawPaint(paintFondo);
			canvas.drawCircle(x+100, y, 30, paintParticula);
			canvas.drawText("y="+y, 50, 50, paint);
			canvas.drawText("t="+tiempo, 50, 90, paint);
			canvas.drawText("v="+velocidad, 50, 130, paint);
		}
		
    }   // fin dinamica


}