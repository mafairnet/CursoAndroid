package com.curso.android;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ModificarTexto04Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    		View v=findViewById(R.id.myTextView);        
    		TextView myTextView=(TextView) v;
    		for(double x=0; x<1; x=x+0.01){
    			double sx=Math.sin(x);
    			myTextView.append("sin(" + x + ") = " + sx + "\n");

    	}    
}

}

