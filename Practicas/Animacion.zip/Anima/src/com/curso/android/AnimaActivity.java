package com.curso.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AnimaActivity extends Activity {
    /** Called when the activity is first created. */
	private TextView texto;
	private Button btnrotar, btnescalar, btntransladar, btntransferencia, btnmezcla1, btnmezcla2;
	private ImageView logo;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        texto = (TextView)findViewById(R.id.textView1);
        logo = (ImageView)findViewById(R.id.logo);
        logo.setBackgroundResource(R.drawable.ic_launcher);
    }
	public void accionarAnimar(View view){
		Animation rotar = AnimationUtils.loadAnimation(this, R.anim.rotar);
		rotar.reset();
		switch (view.getId()){
		case R.id.btnescalar:
			Animation escalar = AnimationUtils.loadAnimation(this, R.anim.escalar);
			escalar.reset();
		logo.startAnimation(escalar);
		break;
		case R.id.btnrotar:
			Animation rotacion = AnimationUtils.loadAnimation(this, R.anim.rotar);
			rotacion.reset();
		logo.startAnimation(rotacion);
		break;
		case R.id.btnmezcla1:
			Animation mezcla1 = AnimationUtils.loadAnimation(this, R.anim.mezcla1);
			mezcla1.reset();
		logo.startAnimation(mezcla1);
		break;
		case R.id.btntransladar:
			Animation mover = AnimationUtils.loadAnimation(this, R.anim.transladar);
			mover.reset();
		logo.startAnimation(mover);
		break;
		case R.id.btntransferencia:
			Animation trans = AnimationUtils.loadAnimation(this, R.anim.transparencia);
			trans.reset();
		logo.startAnimation(trans);
		break;
		case R.id.btnmezcla2:
			Animation mezcla2 = AnimationUtils.loadAnimation(this, R.anim.mezcla2);
			mezcla2.reset();
		logo.startAnimation(mezcla2);
		break;
		}
	}
}