package com.curso.android;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Sonidos extends Activity implements OnClickListener{

	MediaPlayer mplayer;
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button boton1=(Button) findViewById(R.id.boton1);
        boton1.setOnClickListener(this);
        Button boton2=(Button) findViewById(R.id.boton2);
        boton2.setOnClickListener(this);
        Button boton3=(Button) findViewById(R.id.boton3);
        boton3.setOnClickListener(this);
        Button boton4=(Button) findViewById(R.id.boton4);
        boton4.setOnClickListener(this);        
    }            
    @Override
    public void onClick(View v) {        		
        if(mplayer != null) mplayer.release();  // libera el MediaPlayer 
        int id=v.getId();
        if(id == R.id.boton1)
        	mplayer = MediaPlayer.create(this, R.raw.laugh_1);	
        else if(id == R.id.boton2)
        	mplayer = MediaPlayer.create(this, R.raw.laugh_4);	
        else if(id == R.id.boton3)
        	mplayer = MediaPlayer.create(this, R.raw.applause2);	
        else
        	mplayer = MediaPlayer.create(this, R.raw.peoplelaughing1);	
        mplayer.seekTo(10);
        mplayer.start();	
    }  
    @Override
    public void onPause() {
        super.onPause();
        // libera el mediaplayer en el background
        if(mplayer != null) mplayer.release();
        /*
         * 
         * 
         * 
         * 
         * 
         * 
         * 
         * 
         */
        
        
        
        
        
    }    
    
}
