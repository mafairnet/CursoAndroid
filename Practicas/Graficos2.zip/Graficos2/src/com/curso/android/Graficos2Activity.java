package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.os.Bundle;
import android.view.View;

public class Graficos2Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GraficoView grafico = new GraficoView(this);
        setContentView(grafico);
    }
    private class GraficoView extends View{
    	public GraficoView(Context context){
    		super(context);
    	}
    	@Override
    	protected void onDraw(Canvas canvas){
    		int width = canvas.getWidth();
    		int height = canvas.getHeight();
    		canvas.drawColor(Color.WHITE);
    		
    		Paint paintBlack = new Paint();
    		Paint paintBlue = new Paint();
    		//Paint paint = new Paint();
    		paintBlack.setColor(Color.BLACK);
    		paintBlue.setColor(Color.BLUE);
    		for(int i=20;i<height;i+=30){
    			canvas.drawLine(0, i, width, i, paintBlue);
    			canvas.drawText(""+i, 30, i, paintBlack);
    		}
    		paintBlack.setTextSize(40);
    		canvas.drawText("height= "+height, 100, height/2, paintBlack);
    		/* ----------------
    		width = getMeasuredWidth();
    		height = getMeasuredHeight();*/
    		int bottom = getBottom();
    		int right = getRight();
    		paintBlack.setTextAlign(Align.CENTER);
    		canvas.drawText("Width "+width, width/2, 40, paintBlack);
    		canvas.drawText("Height "+height, width/2, 80, paintBlack);
    		canvas.drawText("Right "+right, width/2, 120, paintBlack);
    		canvas.drawText("Bottom "+bottom, width/2, 160, paintBlack);
    		
    		canvas.drawLine(0, 0, right, bottom, paintBlue);
    		canvas.drawLine(right, 0, 0, bottom, paintBlue);
    		
    		canvas.drawLine(0, 0, width, height, paintBlue);
    		canvas.drawLine(width, 0, 0, height, paintBlue); 
    		 
    	}
    	}
}