package com.curso.android;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class GuardarDatosActivity extends Activity {
	
	SharedPreferences misDatos;
	EditText editNombre, editX, editY;
	String nombre;
	Float x,y;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        editNombre = (EditText) findViewById(R.id.nombre);
        editX = (EditText) findViewById(R.id.coordenadaX);
        editY = (EditText) findViewById(R.id.coordenadaY);
        
        //Abre un fichero de preferencia    
        misDatos= getSharedPreferences("file",0);
        //Lee en el fichero de preferencias
        nombre = misDatos.getString("nombre", "Valor por defecto");
        x=misDatos.getFloat("x", 0);
        y=misDatos.getFloat("y", 0);
        //Escribir las preferencias en los campos de texto
        editNombre.setText(nombre);
        editX.setText(" "+x);
        editY.setText(" "+y);
    } 
    protected void onPause(){
    	super.onPause();
    	//Extraer el contenido de los campos de texto
    	nombre=editNombre.getText().toString();
    	x=Float.parseFloat(editX.getText().toString());
    	y=Float.parseFloat(editY.getText().toString());
    	
    	//definimos un editor para mis datos
    	SharedPreferences.Editor miEditor=misDatos.edit();
    	//escribe los datos
    	miEditor.putString("nombre", nombre);
    	miEditor.putFloat("x",x);
    	miEditor.putFloat("y",y);
    	
    	//Salvar
    	miEditor.commit();
    	Toast.makeText(this, "Preferencias Guardadas", 1).show();
    }
}