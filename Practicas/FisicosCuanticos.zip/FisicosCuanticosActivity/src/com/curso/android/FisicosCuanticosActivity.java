package com.curso.android;

import android.app.Activity;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class FisicosCuanticosActivity extends Activity implements OnClickListener{

	MediaPlayer mplayer;
	TextView caption;
	String[] texto={" ",
			"Niels Bohr (1885-1962)." +
			"Contribuyó a la comprensión de la estructura del átomo." +
			"Premio Nobel 1922",
			"Max Plank (1858-1947). " +
			"Sentó las bases de la teoría Cuántica de la materia " +
			"e introdujo la constante de Planck." +
			"Premio Nobel 1918",
			"Pauli. Principio de exclusión. Matrices de Pauli.",
			"Schrodinger (1887-1961) Ecuación de Schrödinger, " +
			"Modelo atómico de Schrödinger y Efecto Túnel."+
			"Premio Nobel 1933"};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        caption=(TextView) findViewById(R.id.caption);

        View boton1=findViewById(R.id.imageButton1);
        boton1.setOnClickListener(this);
        View boton2=findViewById(R.id.imageButton2);
        boton2.setOnClickListener(this);
        View boton3=findViewById(R.id.imageButton3);
        boton3.setOnClickListener(this);
        View boton4=findViewById(R.id.imageButton4);
        boton4.setOnClickListener(this);
        
        musica();
    }

	@Override
	public void onClick(View v) {
		int i=0;
		int id=v.getId();
		if(id == R.id.imageButton1) i=1;
		else if(id == R.id.imageButton2) i=2;
		else if(id == R.id.imageButton3) i=3;
		else if(id == R.id.imageButton4) i=4;
		caption.setTextColor(Color.BLUE);
		caption.setText(texto[i]);
		
	}

	void musica(){
		if(mplayer!=null)mplayer.release();
		mplayer=MediaPlayer.create(this, R.raw.black_magic_woman);
		mplayer.seekTo(0);
		mplayer.start();
		
	}

	@Override
	public void onPause(){
		super.onPause();
		if(mplayer !=null)mplayer.release();
	}

}