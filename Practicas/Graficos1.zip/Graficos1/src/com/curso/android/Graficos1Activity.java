package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;

public class Graficos1Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GraficoView grafico = new GraficoView(this);
        setContentView(grafico);
    }
    
    private class GraficoView extends View{
    	public GraficoView(Context context){
    		super(context);
    	}
    	@Override
    	protected void onDraw(Canvas canvas){
    		super.onDraw(canvas);
    		Paint paint = new Paint();
    		paint.setColor(Color.WHITE);
    		canvas.drawPaint(paint);
    		int width = canvas.getWidth();
    		int height = canvas.getHeight();
    		paint.setColor(Color.BLUE);
    		paint.setTextSize(16);
    		paint.setAntiAlias(true);
    		canvas.drawText("ancho= " + width+" alto= "+height, 120, 140, paint);
    		
    		paint.setColor(Color.rgb(100, 20, 0));
    		canvas.drawLine(0, 140, width, 140, paint);
    		paint.setColor(Color.rgb(0, 100, 20));
    		canvas.drawLine(120, 0, 120, height, paint);
    		paint.setColor(Color.rgb(0, 100, 100));
    		canvas.drawLine(width/2, 0, width/2, height, paint);
    		paint.setTextAlign(Align.RIGHT);
    		canvas.drawText("Aliniado a la Derecha", width/2, 160, paint);
    		paint.setTextAlign(Align.LEFT);
    		paint.setTextSkewX(0.2f);
    		canvas.drawText("InclinadoX 0.2", 0, 210, paint);
    		paint.setTextSkewX(-0.2f);
    		canvas.drawText("InclinadoX 0.2", 0, 230, paint);
    		paint.setTextScaleX(2f);
    		canvas.drawText("Texto con escala x 2", 10, 250, paint);
    		paint.setTextScaleX(-4f);
    		canvas.drawText("Texto con escala x -2", width, 270, paint);
    		paint.setTypeface(Typeface.SANS_SERIF);
    		canvas.drawText("Tipo Sans serif", 20, 300, paint);
    		paint.setTypeface(Typeface.SERIF);
    		canvas.drawText("Tiposerif", 20, 330, paint);


    		    		}
    }
}