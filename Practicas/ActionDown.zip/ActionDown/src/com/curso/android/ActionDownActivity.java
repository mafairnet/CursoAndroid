package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class ActionDownActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        SpecialView myView=new SpecialView(this);
        setContentView(myView);
    }
    class SpecialView extends View{
    	float x=50;
    	float y=50;
    	public SpecialView(Context context){
    		super(context);
    	}
    	protected void onDraw(Canvas canvas){
    		canvas.drawColor(Color.LTGRAY);
    		Paint paint=new Paint();
    		paint.setAntiAlias(true);
    		paint.setColor(Color.RED);
    		canvas.drawCircle(x, y, 20, paint);
    		paint.setColor(Color.BLACK);
    		paint.setTextSize(35);
    		canvas.drawText("x= "+x, 100, 50, paint);
    		canvas.drawText("y= "+y, 100, 90, paint);
    	}
    	public boolean onTouchEvent(MotionEvent evento){
    		if(evento.getAction()==MotionEvent.ACTION_DOWN){
    			x=evento.getX();
    			y=evento.getY();
    			invalidate();
    		}
    		return true;
    	}
     }
}