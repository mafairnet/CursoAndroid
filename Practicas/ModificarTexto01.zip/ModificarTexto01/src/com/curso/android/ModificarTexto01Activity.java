package com.curso.android;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ModificarTexto01Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        TextView myTextView=(TextView)findViewById(R.id.myTextView);
        myTextView.setText("Hemos modificado el TextView con un nuevo " +
        		"texto" + "usando java");
        
        myTextView.setTextColor(Color.argb(255, 255, 0, 0));
        
        TextView tv=new TextView(this);
        tv.setTextColor(Color.argb(2500, 0, 255, 0));
        tv.setTextSize(30);
        tv.setText("a�adiendo nuevo tecto cn un addView");
        
        LinearLayout ll=(LinearLayout)findViewById(R.id.myLayout);
        ll.addView(tv);
        
    }
}