package com.curso.android;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class Ficheros1Activity extends Activity {
	/** Escribir Datos en un Fichero en la tarjeta SD */
	TextView tv;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        tv=(TextView) findViewById(R.id.texto);
        String state=Environment.getExternalStorageState();
        tv.append("\nEstado: " + state);
        
        File root=Environment.getExternalStorageDirectory();
        File dir=new File (root.getAbsolutePath()+"/datos");
        dir.mkdirs();
        tv.append("\n\nNuevo Directorio: "+dir);
        
        tv.append("\n\nContenido del directorio" + root + " :");
        String[]fichero=root.list();
        for(int i=0;i<fichero.length;i++) tv.append("\n" + fichero[i]);
        
        File file=new File(dir,"datos1.txt");
        try{
        	FileOutputStream fos = new FileOutputStream(file);
        	PrintWriter pw = new PrintWriter(fos);
        	pw.println("Primera linea del fichero");
            for(int i=0;i<fichero.length;i++) pw.append("\n" + fichero[i]);
        	pw.flush();
        	pw.close();
        	tv.append("\n\n Fichero grabado");
        }catch(FileNotFoundException e){
        	e.printStackTrace();
        	tv.append("\n\n "+e);
        }
    }
}