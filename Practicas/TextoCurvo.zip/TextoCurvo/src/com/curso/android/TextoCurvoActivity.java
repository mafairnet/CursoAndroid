package com.curso.android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.os.Bundle;
import android.view.View;

public class TextoCurvoActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SpecialView myView = new SpecialView(this);
        setContentView(myView);
    }
    class SpecialView extends View{
    	public SpecialView(Context context){
    		super(context);
    	}
    	protected void onDraw(Canvas canvas){
    		canvas.drawColor(Color.WHITE);
    		Paint paint=new Paint();
    		paint.setTextSize(60);
    		paint.setAntiAlias(true);
    		int width=getWidth();
    		paint.setColor(Color.RED);
    		paint.setStyle(Paint.Style.STROKE);
    		Path path=new Path();
    		Direction dir=Direction.CW;
    		float radio=100;
    		path.addCircle(width/2, 200, radio, dir);
    		path.offset(0, 0);
    		float hOffset=0;
    		float vOffset=-20;
    		canvas.drawPath(path, paint);
    		paint.setColor(Color.BLACK);
    		canvas.drawTextOnPath("texto en path externo", path, hOffset, vOffset, paint);
    		vOffset=20;
    		hOffset=100;
    		paint.setStyle(Paint.Style.FILL);
    		paint.setTextSize(20);
    		canvas.drawTextOnPath("texto interior comenzando a "+hOffset+" del punto inicial", path, hOffset, vOffset, paint);
    		
    		Path trazo = new Path();
    		trazo.moveTo(50, 500);
    		trazo.cubicTo(60, 570, 150, 590, 200, 510);
    		trazo.lineTo(300, 400);
    		Paint pincel = new Paint();
    		pincel.setColor(Color.RED);
    		pincel.setStrokeWidth(8);
    		pincel.setStyle(Style.STROKE);
    		canvas.drawPath(trazo, pincel);
    		paint.setStyle(Paint.Style.FILL);
    		paint.setTextSize(20);
    		paint.setColor(Color.BLACK);
    		canvas.drawTextOnPath("texto en path irregular y se distorciona", trazo , 10, 40, paint);

    	}
    }
}