package com.curso.android;


import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.content.Context;


public class MoverObjetosActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SpecialView myView=new SpecialView(this);
        setContentView(myView);
    }
    
    class SpecialView extends View{
    	float[] x={50,50};
    	float[] y={50,150};
    	float[] radio={40,60};
    	Paint paint[]=new Paint[2];
    	Paint p;
    	int seleccion=-1;
    	String texto="Mueve los circulos";
    	
    	public SpecialView(Context context){
    		super(context);
    		paint[0]=new Paint();
    		paint[1]=new Paint();
    		paint[0].setColor(Color.RED);
    		paint[1].setColor(Color.GREEN);
    		p=new Paint();
    		p.setTextSize(30);
    		p.setColor(Color.BLACK);
    	}
    	protected void onDraw(Canvas canvas){
    		canvas.drawColor(Color.WHITE);
    		canvas.drawText(texto, 200, 50, p);
    		for(int i=0;i<2;i++){
    			canvas.drawCircle(x[i], y[i], radio[i], paint[i]);
    		}
    	}
    	public boolean onTouchEvent(MotionEvent evento){
    		float newX = evento.getX();
    		float newY = evento.getY();
    		
    		if(evento.getAction()==MotionEvent.ACTION_DOWN){
    			//indice del circulo seleccionado
    			// -1 si no hay selecci�n
    			seleccion=-1;
    			for(int i=0;i<2;i++){
    				//Calcular la distancia al centro de cada circulo
    				double dx=newX-x[i];
    				double dy=newY-y[i];
    				float distancia=(float)Math.sqrt(dx*dx+dy*dy);
    				if(distancia<=radio[i]){
    					//Si estamos dento de algun circulo lo seleccionamos
    					seleccion=i;
    					texto="Seleccion "+i;
    					invalidate();
    				}
    			}
    		}
    		if(evento.getAction()==MotionEvent.ACTION_MOVE){
    			if(seleccion > -1){
    				//Si hay un circulo seleccionado lo trasladamos al nuevo punto
    				x[seleccion]=newX;
    				y[seleccion]=newY;
    				invalidate();
    			}
    		}
    		return true;
    	}
    
    }
}